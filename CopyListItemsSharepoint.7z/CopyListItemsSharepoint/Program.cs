﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using System.IO;

namespace CopyListItemsSharepoint
{
    class Program
    {
        static void Main(string[] args)
        {
               SPSite site = new SPSite("http://sharepointsrv/sites/portal/");
               SPWeb web = site.OpenWeb();
               SPList sourceList = web.Lists["Обучение 2013"];
                     foreach (SPListItem sourceItem in sourceList.Items)
                        {
                         SPSite destsite = new SPSite("http://sharepointsrv:8080/sites/archive/");
                         SPWeb destweb = destsite.OpenWeb();
                         SPList destinationList = destweb.Lists["Обучение 2013"];
                         SPListItem destItem = destinationList.Items.Add();
                                        foreach (SPField field in sourceItem.Fields)
                                        {
                                            if (!field.ReadOnlyField && field.InternalName != "Attachments")
                                            {
                                                if (destItem.Fields.ContainsField(field.InternalName))
                                                {
                                                    destItem[field.InternalName] = sourceItem[field.InternalName];
                                                }
                                                                                                  
                                            }
                                        }
                                        foreach (string fileName in sourceItem.Attachments)
                                        {
                                            SPFile file = sourceItem.ParentList.ParentWeb.GetFile(sourceItem.Attachments.UrlPrefix + fileName);
                                            byte[] bData = file.OpenBinary();
                                            destItem.Attachments.Add(fileName, bData);
                                        }
                                        destItem.Update();
                                 }
                            }
           
                    
  }
         
}
        
    



